#include <catch2/catch_test_macros.hpp>
#include "../../../src/improvement/enum/example_2.hpp"

TEST_CASE("Improvement : ENUM : Example 2 running") {

    register_a_phone_number(NATIONAL_NUMBER::CONGO, 467485849);
    register_a_phone_number(NATIONAL_NUMBER::EGYPT, 222332552);
    register_a_phone_number(NATIONAL_NUMBER::UK, 999944855);

}