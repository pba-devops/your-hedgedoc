#include <catch2/catch_test_macros.hpp>
#include "../../../src/improvement/enum/example_1.hpp"

TEST_CASE("Improvement : ENUM : Example 1 running") {

    register_a_phone_number(242, 448384783);
    register_a_phone_number(20, 447375);
    register_a_phone_number(33, 3284463645); // BAD ONE --

}