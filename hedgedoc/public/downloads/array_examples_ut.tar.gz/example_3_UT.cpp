#include <catch2/catch_test_macros.hpp>
#include "../../../src/improvement/array/example_3.hpp"

TEST_CASE("Improvement : ARRAY : Example 3 running") {

    simple_array_declaration();
    array_item_assignment();
    array_declaration_assignment_one_shot();
    array_size();
    array_items_access_with_loop();
    array_items_access_with_for_each();

}