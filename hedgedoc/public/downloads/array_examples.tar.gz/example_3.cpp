#include "example_3.hpp"
#include <iostream>

void simple_array_declaration() {

    int array_of_int[4];
    std::cout << "array_of_int[0] = " << array_of_int[0] << std::endl;
    std::cout << "array_of_int[1] = " << array_of_int[1] << std::endl;
    std::cout << "array_of_int[2] = " << array_of_int[2] << std::endl;
    std::cout << "array_of_int[3] = " << array_of_int[3] << std::endl << std::endl;

}

void array_item_assignment() {

    int array_of_int[4];

    array_of_int[0] = 20;
    array_of_int[1] = 72;
    array_of_int[2] = 10;
    array_of_int[3] = 5;

    std::cout << "array_of_int[0] = " << array_of_int[0] << std::endl;
    std::cout << "array_of_int[1] = " << array_of_int[1] << std::endl;
    std::cout << "array_of_int[2] = " << array_of_int[2] << std::endl;
    std::cout << "array_of_int[3] = " << array_of_int[3] << std::endl << std::endl;

}

void array_declaration_assignment_one_shot() {

    int array_of_int[] = {20,72,10,5};

    std::cout << "array_of_int[0] = " << array_of_int[0] << std::endl;
    std::cout << "array_of_int[1] = " << array_of_int[1] << std::endl;
    std::cout << "array_of_int[2] = " << array_of_int[2] << std::endl;
    std::cout << "array_of_int[3] = " << array_of_int[3] << std::endl << std::endl;

}

void array_size() {

    int array_of_int[] = {20,72,10,5};
    int bytes_of_array = sizeof(array_of_int);
    int bytes_of_cell = sizeof(array_of_int[0]);
    int size_of_array = bytes_of_array / bytes_of_cell;

    std::cout << "array_of_int - size = [ " << size_of_array << " ]" << std::endl << std::endl;

}

void array_items_access_with_loop() {

    int array_of_int[] = {20,72,10,5};
    int size_of_array = sizeof(array_of_int) / sizeof(array_of_int[0]);

    for(int index = 0 ; index < size_of_array ; index++) {
        std::cout << "array_of_int["  << index << "] -> [ " << array_of_int[index] << " ]" << std::endl;
    }

    std::cout << std::endl;

}

void array_items_access_with_for_each() {

    int array_of_int[] = {20,72,10,5};
    int bytes_of_array = sizeof(array_of_int);
    int bytes_of_cell = sizeof(array_of_int[0]);
    int size_of_array = bytes_of_array / bytes_of_cell;

    std::cout << "array_of_int - size = [ " << size_of_array << " ]" << std::endl;

    for(int item : array_of_int) {
        std::cout << "- [ " << item << " ]" << std::endl;
    }

    std::cout << std::endl;

}
