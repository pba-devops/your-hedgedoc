#ifndef GLASSOFWATER_EXAMPLE_3_HPP
#define GLASSOFWATER_EXAMPLE_3_HPP

    void simple_array_declaration();
    void array_item_assignment();
    void array_declaration_assignment_one_shot();
    void array_size();
    void array_items_access_with_loop();
    void array_items_access_with_for_each();

#endif //GLASSOFWATER_EXAMPLE_3_HPP
