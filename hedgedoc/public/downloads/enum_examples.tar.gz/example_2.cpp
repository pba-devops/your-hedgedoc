#include "example_2.hpp"

void register_a_phone_number(NATIONAL_NUMBER national_number, uint phone_number) {

    std::cout << "Phone number [ (" << national_number << ") " << phone_number << " ] IS RECORDED" << std::endl;

}