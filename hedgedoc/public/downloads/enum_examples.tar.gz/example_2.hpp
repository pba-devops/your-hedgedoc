#ifndef GLASSOFWATER_EXAMPLE_2_HPP
#define GLASSOFWATER_EXAMPLE_2_HPP

    #include <iostream>

    enum NATIONAL_NUMBER {
        CONGO = 242,
        EGYPT = 20,
        UK = 44
    };

    void register_a_phone_number(NATIONAL_NUMBER national_number, uint phone_number);

#endif //GLASSOFWATER_EXAMPLE_2_HPP
