#ifndef GLASSOFWATER_EXAMPLE_1_HPP
#define GLASSOFWATER_EXAMPLE_1_HPP

    #include <iostream>

    void register_a_phone_number(uint national_number, uint phone_number);

#endif //GLASSOFWATER_EXAMPLE_1_HPP
