#include "example_1.hpp"

void register_a_phone_number(uint national_number, uint phone_number) {

    if(national_number != 242 &&
       national_number != 20 &&
       national_number != 44) {

        std::cout << "Phone number [ (" << national_number << ") " << phone_number << " ] CANNOT BE RECORDED : NATIONAL NUMBER (" << national_number << ") IS OUT OF SCOPE" << std::endl;

    } else {
        std::cout << "Phone number [ (" << national_number << ") " << phone_number << " ] IS RECORDED" << std::endl;
    }

}